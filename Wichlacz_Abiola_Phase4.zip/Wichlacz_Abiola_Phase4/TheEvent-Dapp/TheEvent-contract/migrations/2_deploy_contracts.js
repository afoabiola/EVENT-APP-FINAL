var ERCEvent = artifacts.require("ERCEvent");
var EVNTPayments = artifacts.require("EVNTPayments");
var TheEventFunctions = artifacts.require("TheEventFunctions");

module.exports = function(deployer) {
    deployer.deploy(ERCEvent)
        .then(() => ERCEvent.deployed())
        .then(() => deployer.deploy(EVNTPayments, ERCEvent.address))
        .then(() => EVNTPayments.deployed())
        .then(() => deployer.deploy(TheEventFunctions, ERCEvent.address, EVNTPayments.address));
}
App = {
  web3Provider: null,
  contracts: {},
  userAccount: null,
  currentAccount: null,
  overallInstance:null,
  Event_APP_ABI: [
    {
      "inputs": [],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "_numTix",
          "type": "uint256"
        }
      ],
      "name": "buyTickets",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "X",
          "type": "uint256"
        }
      ],
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        }
      ],
      "name": "eventName",
      "outputs": [
        {
          "internalType": "string",
          "name": "EventName",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        }
      ],
      "name": "myTickets",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "Tix",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_name",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "_supply",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "_price",
          "type": "uint256"
        }
      ],
      "name": "publishEvent",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "userAddress",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "redeemNumTix",
          "type": "uint256"
        }
      ],
      "name": "redeemTickets",
      "outputs": [
        {
          "internalType": "bool",
          "name": "admit",
          "type": "bool"
        }
      ],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "registerCreator",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "registerUser",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        }
      ],
      "name": "tixPrice",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "Price",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        }
      ],
      "name": "tixRemain",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "Supply",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "_to",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "eventID",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "transferValue",
          "type": "uint256"
        }
      ],
      "name": "transferTickets",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ],
  names: new Array(),
  url: 'http://127.0.0.1:7545',
  chairPerson: null,
  currentAccount: null,

  init: function () {
    console.log("Checkpoint 0");
    return App.initWeb3();
  },

  initWeb3: function () {
    // Is there is an injected web3 instance?
    if (typeof web3 !== 'undefined') {
      App.web3Provider = web3.currentProvider;
    } else {
      // If no injected web3 instance is detected, fallback to the TestRPC
      App.web3Provider = new Web3.providers.HttpProvider('http://127.0.0.1:8545');
    }
    console.log("Checkpoint 1 -- Initialized Web3");
    web3 = new Web3(App.web3Provider);
    ethereum.enable();
    return App.initContract();
  },

  initContract: function () {
    $.getJSON('TheEventFunctions.json', function (data) {
      // Grabs the needed contract artifact file
      var eventFunctionsArtifact = data;
      App.contracts.TheEventFunctions = TruffleContract(eventFunctionsArtifact);
      App.contracts.myContract = data;

      // Set the provider for our contract
      App.contracts.TheEventFunctions.setProvider(App.web3Provider);
      
    });
    console.log("Checkpoint 2 -- Initialized Contract");
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    
    return App.TheEventFunctions();
  },

  TheEventFunctions: function () {
    $(document).on('click', '#reguser', App.regUser);
    $(document).on('click', '#regcreate', App.regCreator);
    $(document).on('click', '#buytix', App.tixBuy);
    $(document).on('click', '#pubEvent', App.pubEvent);
    $(document).on('click', '#getTix', App.getTix);
    $(document).on('click', '#priceTix', App.PriceTix);
    $(document).on('click', '#redeem', function(){var cust_addr = $("#redeem-user").val(); App.tixRedeem(cust_addr)});    // THIS ALLOWS THE  ADDRESS OF THE RECIEVER TO BE PASS TO THE FUNCTION
    $(document).on('click', '#trans', function(){var addrs = $("#user_add").val();App.tixTransfer(addrs)});               // THIS ALLOWS THE  ADDRESS OF THE RECIEVER TO BE PASS TO THE FUNCTION
    $(document).on('click', '#getName', function(){var event_id = parseInt($("#get-event-name").val()); App.NameEvent(event_id)});
    $(document).on('click', '#remain', function(){var even = parseInt($("#remain-tix").val()); App.RemainTix(even)});
    $(document).on('click', '#event-bal', App.eventbal);
    $(document).on('click', '#approve-tix', App.tixApprove);
    console.log("Checkpoint 3 -- Functions On");
  },

  regUser: function() {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var userInstance = instance;
      return userInstance.registerUser({from:App.userAccount});
    }).then(function(result, err) {
      if(result){
        console.log(result.receipt.status);
        toastr["success"]("User Registration Successful")
      }
      else {
        console.log("User Registration Failed, Error Below:");
        console.log(err);
        toastr["error"]("User Registration Failed");
      }
    }).catch(function(err){
      toastr["error"]("Caught Error in Registering User");
    })
  },

  regCreator : function(){
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var creatorInstance = instance;
      return  creatorInstance.registerCreator({from:App.userAccount});
    }).then(function(result, err) {
      if(result) {
        console.log(result.receipt.status);
        toastr["success"]("Creator Registration Successful");
      }
      else {
        console.log("Creator Registration Failed, Error Below:");
        console.log(err);
        toastr["error"]("Error in Registering Creator");
      }
    }).catch(function(err) {
      toastr["error"]("Caught Error in Registering Creator");
    })
  },

  pubEvent: function() {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);//REFRESHES THE CURRENT ACCOUNT WITH EVERY FUNCTION CALL

    //3 values pulled form the front end based on div name and on click
    var ticketNumber = parseInt($("#num-tix-event").val());
    var ticketPrice = parseInt($("#ticket-price-event").val());
    var event_name = $("#event-name-value").val();
    if($("#num-tix-event").val() == ""|| $("#ticket-price-event").val() ==""||$("#event-name-value").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];

    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var publishInstance = instance;
      return publishInstance.publishEvent(event_name, ticketNumber, ticketPrice, {from:App.userAccount});
    }).then(function(result, err) {
      if(result){
        console.log(result.receipt.status);
        toastr["success"]("New Event Published");
      }
      else{
        console.log("Event Publication Failed, Error Below:");
        console.log(err);
        toastr["error"]("Error in Publishing Event");
      }
    }).catch(function(err){
      toastr["error"]("Caught Error in Publishing Event");
    })
  }
  },

  getTix: function () {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#get-id-get-tix").val(), 10); 
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var ticketBalInstance = instance;
      return ticketBalInstance.myTickets(event_id,{from:App.userAccount});
    }).then(function(result) {

      console.log(result);
      console.log(typeof result);
      var s = result.c[0];
      console.log(s);
      toastr["success"]("YOU HAVE " + s + " TICKETS FOR THIS EVENT!");
      //alert("YOU HAVE " + s + " TICKETS FOR THIS EVENT!");
    })
  },

  NameEvent: function (event_id) {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    //var event_id = parseInt($("#get-event-name").val()); 
    if($("#get-id").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];

    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var eventNameInstance = instance;
      return eventNameInstance.eventName(event_id,{from:App.userAccount});
    }).then(function(result) {
      console.log(result);
      console.log(typeof result);
      toastr["success"]("THE EVENT NAME YOU SEARCHED FOR : " + result);
      //alert("THE EVENT NAME YOU SEARCHED FOR : " + result);
    })
  }
  },

  RemainTix: function (event_id) {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    //var event_id = parseInt($("#remain-tix").val(), 10); 
    if($("#remain-tix").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];

    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var ticketsRemainInstance = instance;
      return ticketsRemainInstance.tixRemain(event_id,{from:App.userAccount});
    }).then(function(result) {

      console.log(result);
      console.log(typeof result);
      var j = result.c[0];
      console.log(j);
      toastr["success"](j + "  TICKETS REMAIN FOR THIS EVENT!");
      //alert(j + "  TICKETS REMAIN FOR THIS EVENT!");
      
    })
  }
  },

  PriceTix: function (){
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#id-price").val());
    var ticket_num = parseInt($("#num-tix-price").val());
    if($("#id-price").val()==""||$("#num-tix-price").val() == "")
    {
      toastr["error"]["An Input Field has not been filled"];

    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var ticketPriceInstance = instance;
      return ticketPriceInstance.tixPrice(event_id,{from:App.userAccount});
    }).then(function(result) {
      console.log(result);
      console.log(typeof result);
      var k = result.c[0];
      console.log(k);
      //result is a Javascript object
      var b = k * ticket_num; 
      toastr["success"]("PRICE OF TICKET FOR THE EVENT: " + b + " EVNT for " + ticket_num + " TICKETS");
      //alert("PRICE OF TICKET FOR THE EVENT: " + b + " EVNT for " + ticket_num + " TICKETS");
    })
  }
  },
  

  tixBuy: function() {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#get-id-tix-buy").val());
    var numTick =  parseInt($("#tickets").val());

    if($("#get-id-tix-buy").val() ==""||$("#tickets").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];

    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var buyInstance = instance;
      return buyInstance.buyTickets(event_id,numTick,{from:App.userAccount});
    }).then(function(result, err)
    {
      if(result) {
        console.log(result.receipt.status);
        //var g = result.c[0]
        toastr["success"]("EventID: " + event_id + ", " + numTick + " Tickets Purchased");
      }
      else {
        console.log("Error in Purchasing Tickets, Error Below:");
        //console.log(err);
        toastr["error"]("Error in Purchasing Tickets");
      }
    }).catch(function(err){
      console.log(err)
      toastr["error"]("Caught Error in Purchasing Tickets");
    })
  }
  },

  tixRedeem: function(Useraddress) {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#event-id-reed").val());
    var numTick =  parseInt($("#ticket-reed").val());
    //var Useraddress = parseInt($("redeem-user").val(),16);
    if($("#event-id-reed").val() == ""||$("#ticket-reed").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];
    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var redeemInstance = instance;
      return redeemInstance.redeemTickets(Useraddress, event_id, numTick,{from:App.userAccount});
    }).then(function(result, err) {
      if(result) {
        console.log(result.receipt.status);
        toastr["success"]("EventID: " + event_id + ", " + "Successfully Redeemed " + numTick + " Tickets");
      }
      else {
        console.log("Error in Redeeming Tickets, Error Below:");
        console.log(err);
        toastr["error"]("Error in Redeeming Tickets");
      }
    }).catch(function(err){
      toastr["error"]("Caught Error in Redeeming Tickets");
    })
  }
  },

  tixTransfer: function(address) {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#event-id-trans").val());
    var numTickTrans =  parseInt($("#ticket-trans").val());
    //var address = $("#user_add").val();
    if($("#event-id-trans").val() == ""||$("#ticket-trans").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];
    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var transferInstance = instance;
      return transferInstance.transferTickets(address,event_id,numTickTrans,{from:App.userAccount});
    }).then(function(result, err) {
      console.log(result);
      if(result) {
        console.log(result.receipt.status);
        toastr["success"]("EventID: " + event_id + ", " + "Successfully Transfered " + numTickTrans + " Tickets");
      }
      else {
        console.log("Error in Transfering Tickets, Error Below:");
        console.log(err);
        toastr["error"]("Error in Transfering Tickets");
      }
    }).catch(function(err){
      console.log(err);
      toastr["error"]("Caught Error in  transfering tickets");
    })
  }
  },

  tixApprove: function() {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    var event_id = parseInt($("#get-id-tix-buy-approve").val(),10);
    var numTick =  parseInt($("#tickets-approve").val(),10);
    if($("#get-id-tix-buy-approve").val() == "" || $("#tickets-approve").val() =="")
    {
      toastr["error"]["An Input Field has not been filled"];
    }
    else{
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var approvalInstance = instance;
      console.log("CHECKPOINT APPROVE");
      return approvalInstance.approveTickets(event_id,numTick,{from:App.userAccount});
    }).then(function(result, err){
      console.log(result);
      
      if(result) {
        //console.log(result);
        toastr["success"]("EventID: " + event_id + ", " + "Successfully Approved for " + numTick + " Tickets");
      }
      else {
        console.log("Error in Approving Tickets, Error Below:");
        console.log(err);
        toastr["error"]("Error in Approving Tickets");
      }
    }).catch(function(err){
      console.log(err);
      toastr["error"]("Caught Error in approving Tickets");
    })
  }
  },

  eventbal: function() {
    App.userAccount = web3.eth.coinbase;
    jQuery('#current_account').text(App.userAccount);
    App.contracts.TheEventFunctions.deployed().then(function(instance) {
      var evntInstance = instance;
      return evntInstance.evntBal({from:App.userAccount});
    }).then(function(result) {
      console.log(result);
      console.log(typeof result);
      var e = Math.round(result.c[0] * Math.pow(10 , -4));
      console.log(e);
      toastr["success"]("YOUR EVNT BALANCE IS : " + e + " EVNT");
      //alert("YOUR EVNT BALANCE IS : " + e + " EVNT");
    })
  }
};

$(function () {
  $(window).load(function () {
    App.init();
    //Notification UI config
    toastr.options = {
      "showDuration": "1000",
      "positionClass": "toast-top-left",
      "preventDuplicates": true,
      "closeButton": true
    };
  });
});

// code for reloading the page on account change
window.ethereum.on('accountsChanged', function (){
  location.reload();
})